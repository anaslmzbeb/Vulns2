#pragma once

#define HTTP_SERVER "91.208.206.226"
#define HTTP_PORT 80

#define TFTP_SERVER "91.208.206.226"
